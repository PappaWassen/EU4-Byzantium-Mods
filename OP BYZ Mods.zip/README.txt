HOW TO INSTALL



Download OP BYZ MODS.zip

place .zip in EU4 mods file



IF YOU HAVE 7-ZIP


Right click .zip file

click 7-Zip > Extract Here



IF YOU DONT HAVE 7-ZIP



right click .zip file

click Extract All...

delete the "\OP BYZ MODS" in the "Europa Universalis IV\mod\OP BYZ Mods"

click Extract



You can now select this mod in the EU4 mods tab.